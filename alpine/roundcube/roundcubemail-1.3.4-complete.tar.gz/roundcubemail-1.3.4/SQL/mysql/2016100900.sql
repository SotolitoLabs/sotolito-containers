ALTER TABLE `session` MODIFY `ip` varchar(40) NOT NULL;
