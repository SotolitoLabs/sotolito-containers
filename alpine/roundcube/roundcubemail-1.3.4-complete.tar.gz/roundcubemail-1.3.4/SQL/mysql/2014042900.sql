ALTER TABLE `users` CHANGE `preferences` `preferences` longtext;
